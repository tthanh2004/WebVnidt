# Hướng dẫn Triển khai (Deployment Guide) - VNiDT CMS

Mã nguồn này bao gồm Backend (NestJS) và Frontend (đã được gộp vào thư mục `public` của Backend). Bạn chỉ cần khởi chạy một ứng dụng duy nhất là có thể phục vụ toàn bộ website.

## 1. Yêu cầu hệ thống (Linux)
- Node.js (phiên bản 18 hoặc 20 trở lên)
- Nginx (để làm Reverse Proxy)
- PM2 (để quản lý process)

## 2. Cài đặt các thành phần cơ bản trên Server
Mở terminal trên Server Linux và chạy các lệnh sau:

```bash
# Cài đặt Node.js (sử dụng NVM hoặc cài đặt trực tiếp)
curl -fsSL https://deb.nodesource.com/setup_20.x | sudo -E bash -
sudo apt-get install -y nodejs

# Cài đặt PM2
sudo npm install pm2 -g
```

## 3. Cài đặt ứng dụng
1. Giải nén file `vnidt-release.zip` vào thư mục mong muốn trên server (ví dụ: `/var/www/vnidt`).
2. Di chuyển vào thư mục đó:
   ```bash
   cd /var/www/vnidt
   ```
3. Cài đặt các thư viện (chỉ cài đặt dependency cho production):
   ```bash
   npm install --omit=dev
   ```
4. Thiết lập file `.env`:
   - Copy từ `.env.example`: `cp .env.example .env`
   - Chỉnh sửa các thông số trong `.env` (như JWT_SECRET, cấu hình SMTP gửi email).
5. Khởi tạo Database SQLite:
   ```bash
   npx prisma generate
   npx prisma db push
   ```

## 4. Khởi chạy với PM2
```bash
# Khởi chạy ứng dụng
pm2 start ecosystem.config.js

# Thiết lập PM2 tự khởi động cùng hệ thống
pm2 startup
pm2 save
```

## 5. Cấu hình Nginx (Reverse Proxy)
Tạo một file cấu hình cho Nginx (ví dụ `/etc/nginx/sites-available/vnidt.vn`):

```nginx
server {
    listen 80;
    server_name vnidt.vn www.vnidt.vn;

    location / {
        proxy_pass http://localhost:3000;
        proxy_http_version 1.1;
        proxy_set_header Upgrade $http_upgrade;
        proxy_set_header Connection 'upgrade';
        proxy_set_header Host $host;
        proxy_cache_bypass $http_upgrade;
    }
}
```
Sau đó kích hoạt cấu hình:
```bash
sudo ln -s /etc/nginx/sites-available/vnidt.vn /etc/nginx/sites-enabled/
sudo nginx -t
sudo systemctl reload nginx
```

Chúc bạn triển khai hệ thống thành công!
